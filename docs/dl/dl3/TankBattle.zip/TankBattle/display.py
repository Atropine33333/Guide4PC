"""Terminal rendering: colors, fixed-width cells, frame diffing and the HUD."""

import os
import shutil
import sys
import unicodedata

from config import (
    ARMOR_HP_COLORS, BULLET_COLORS, BULLET_GLYPH, CELL_WIDTH, COLORS,
    FIELD_HEIGHT, FIELD_WIDTH, FOREST, POWERUP_TYPES, STATE_GAME_OVER,
    STATE_PAUSED, STATE_READY, STATE_STAGE_CLEAR, TERRAIN_COLORS,
    TERRAIN_GLYPHS,
)


def colorize(text: str, color: str | None = None) -> str:
    """Wrap *text* in ANSI escape codes for *color*."""
    if not color:
        return text
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"


def display_width(text: str) -> int:
    """Return how many terminal columns *text* occupies."""
    return sum(
        2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
        for ch in text
    )


def pad(text: str, width: int = CELL_WIDTH) -> str:
    """Right-pad *text* with spaces so it fills *width* columns."""
    missing = width - display_width(text)
    if missing > 0:
        return text + " " * missing
    return text


def cell(text: str, color: str | None = None) -> str:
    """Render one battlefield tile as a fixed-width, colored cell."""
    return colorize(pad(text), color)


def enable_windows_ansi() -> None:
    """Turn on VT escape processing for the Windows console, if possible."""
    if os.name != "nt":
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


class Renderer:
    """Draws full frames, rewriting only the lines that changed."""

    def __init__(self) -> None:
        self._lines: list[str] = []
        self._size = (0, 0)

    def start(self) -> None:
        """Switch to the alternate screen and hide the cursor."""
        enable_windows_ansi()
        sys.stdout.write("\033[?1049h\033[2J\033[H\033[?25l")
        sys.stdout.flush()

    def stop(self) -> None:
        """Restore the normal screen, cursor and colors."""
        sys.stdout.write("\033[0m\033[?25h\033[2J\033[?1049l")
        sys.stdout.flush()
        self._lines = []

    def draw(self, lines: list[str]) -> None:
        """Write *lines* at the top of the screen, touching only changes."""
        size = shutil.get_terminal_size((80, 24))
        if (size.columns, size.lines) != self._size:
            self._size = (size.columns, size.lines)
            self._lines = []          # force a full redraw after a resize
        out = []
        for index in range(max(len(lines), len(self._lines))):
            new_line = lines[index] if index < len(lines) else ""
            old_line = self._lines[index] if index < len(self._lines) else None
            if new_line != old_line:
                out.append(f"\033[{index + 1};1H{new_line}\033[K")
        if out:
            sys.stdout.write("".join(out))
            sys.stdout.flush()
        self._lines = list(lines)


# ------------------------------------------------------------------ frame
def render_frame(game) -> list[str]:
    """Build every output line for the current game state."""
    board = _build_board(game)
    _draw_overlays(game, board)
    lines = ["".join(row) for row in board]
    lines.extend(_hud_lines(game))
    return lines


def _build_board(game) -> list[list[str]]:
    grid = game.grid
    board = [
        [cell(TERRAIN_GLYPHS[tile] + " ", TERRAIN_COLORS[tile])
         for tile in row]
        for row in grid
    ]

    for powerup in game.powerups:
        info = POWERUP_TYPES[powerup.kind]
        color = info["color"]
        if powerup.ttl < 3.0 and int(powerup.ttl * 8) % 2 == 0:
            color = "bright_white"
        board[powerup.row][powerup.col] = cell(info["glyph"] + " ", color)

    for bullet in game.bullets:
        if bullet.alive:
            color = BULLET_COLORS[bullet.faction]
            board[bullet.row][bullet.col] = cell(f" {BULLET_GLYPH} ", color)

    for enemy in game.enemies:
        if not enemy.alive or grid[enemy.row][enemy.col] == FOREST:
            continue
        color = enemy.color
        if enemy.type_name == "armor":
            color = ARMOR_HP_COLORS.get(enemy.hp, color)
        board[enemy.row][enemy.col] = cell(enemy.char + enemy.mark(), color)

    player = game.player
    if player.alive:
        color = player.color
        if player.shield_time > 0 and int(game.time * 10) % 2 == 0:
            color = "bright_cyan"
        board[player.row][player.col] = cell(player.char + player.mark(),
                                             color)

    for effect in game.effects:
        board[effect.row][effect.col] = cell(effect.char + " ", effect.color)

    return board


def _draw_overlays(game, board: list[list[str]]) -> None:
    middle = FIELD_HEIGHT // 2
    if game.state == STATE_READY:
        overlay(board, f"第 {game.stage} 关", middle - 2, "bright_yellow")
        overlay(board, "准备", middle, "bright_white")
    elif game.state == STATE_STAGE_CLEAR:
        overlay(board, "关卡完成", middle - 1, "bright_green")
    elif game.state == STATE_PAUSED:
        overlay(board, "暂 停", middle - 1, "bright_white")
        overlay(board, "按 P 继续", middle + 1, "gray")
    elif game.state == STATE_GAME_OVER:
        overlay(board, "游戏结束", middle - 2, "bright_red")
        overlay(board, game.over_reason, middle, "bright_white")
        overlay(board, "按 R 重新开始   按 Q 退出", middle + 2, "yellow")


def overlay(board: list[list[str]], text: str, row: int,
            color: str = "bright_white") -> None:
    """Write *text* centered on one board row, replacing cells.

    Chinese characters take one full cell; ASCII runs are packed three
    characters per cell so mixed text stays compact.
    """
    if not 0 <= row < FIELD_HEIGHT:
        return
    cells = _text_cells(text)
    start = max(0, (FIELD_WIDTH - len(cells)) // 2)
    for offset, content in enumerate(cells):
        col = start + offset
        if col >= FIELD_WIDTH:
            break
        board[row][col] = cell(content, color)


def _text_cells(text: str) -> list[str]:
    """Split *text* into cell-sized chunks (one wide char or three narrow)."""
    cells: list[str] = []
    run = ""
    for char in text:
        if display_width(char) == 2:
            if run:
                cells.extend(run[i:i + 3] for i in range(0, len(run), 3))
                run = ""
            cells.append(char)
        else:
            run += char
    if run:
        cells.extend(run[i:i + 3] for i in range(0, len(run), 3))
    return cells


def _hud_lines(game) -> list[str]:
    shield = "  护盾" if game.player.shield_time > 0 else ""
    hud = (
        f"{colorize('分数', 'bright_white')} {game.score:06d}  "
        f"{colorize('最高', 'bright_white')} {game.high_score:06d}  "
        f"{colorize('关卡', 'bright_white')} {game.stage}  "
        f"{colorize('生命', 'bright_white')} {game.lives}  "
        f"{colorize('火力', 'bright_white')} {game.player.power + 1}/4  "
        f"{colorize('敌军', 'bright_white')} {game.enemies_remaining}"
        f"{colorize(shield, 'bright_cyan')}"
    )
    controls = colorize("移动 WASD/方向键   开火 J/空格   暂停 P   退出 Q", "gray")
    message = colorize(game.message, game.message_color) if game.message else ""
    return [hud, controls, message]
