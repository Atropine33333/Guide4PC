"""Enemy tanks with simple real-time AI."""

import random

from config import (
    DELTAS, ENEMY_MOVE_INTERVAL, ENEMY_SHOOT_MAX, ENEMY_SHOOT_MIN,
    ENEMY_TYPES, OPPOSITE,
)
from tank import Tank


class Enemy(Tank):
    """An enemy tank that hunts the base and the player."""

    def __init__(self, row: int, col: int, type_name: str = "basic") -> None:
        info = ENEMY_TYPES[type_name]
        super().__init__(
            row, col, info["char"], info["color"], hp=info["hp"],
            move_interval=ENEMY_MOVE_INTERVAL / info["speed"],
            faction="enemy",
        )
        self.type_name = type_name
        self.bullet_speed = info["bullet_speed"]
        self.score = info["score"]
        self.shoot_cooldown = 0.6
        self.shoot_timer = random.uniform(0.5, 1.4)
        self.plan = None                 # ordered list of directions to try
        self.rethink_timer = random.uniform(0.2, 0.8)

    def update(self, dt: float, game) -> None:
        """Move, rethink and shoot for one frame."""
        if not self.alive:
            return
        self.cooldown = max(0.0, self.cooldown - dt)
        if game.freeze_time > 0:
            return

        self.rethink_timer -= dt
        if self.rethink_timer <= 0:
            self.plan = None
            self.rethink_timer = random.uniform(0.6, 1.3)

        self.move_accum += dt
        while self.move_accum >= self.move_interval:
            self.move_accum -= self.move_interval
            self._step(game)

        self._update_shooting(dt, game)

    # ------------------------------------------------------------------ move
    def _step(self, game) -> None:
        if not self.plan:
            self.plan = self._choose_path(game)
        for order, direction in enumerate(self.plan):
            if self.try_move(direction, game):
                if order:
                    self.plan.insert(0, self.plan.pop(order))
                return
        # Boxed in: turn around and pick a new plan next tick.
        self.direction = OPPOSITE[self.direction]
        self.plan = [self.direction]

    def _choose_path(self, game) -> list[str]:
        """Return directions ordered from most to least useful."""
        if random.random() < 0.5:
            target_row, target_col = game.base_position
        else:
            target_row, target_col = game.player.position
        dr = target_row - self.row
        dc = target_col - self.col
        horizontal = "right" if dc > 0 else "left"
        vertical = "down" if dr > 0 else "up"

        preferred: list[str] = []
        if abs(dr) > abs(dc):
            if dr:
                preferred.append(vertical)
            if dc:
                preferred.append(horizontal)
        else:
            if dc:
                preferred.append(horizontal)
            if dr:
                preferred.append(vertical)

        rest = [d for d in DELTAS if d not in preferred]
        random.shuffle(rest)
        return preferred + rest

    # ----------------------------------------------------------------- shoot
    def _update_shooting(self, dt: float, game) -> None:
        self.shoot_timer -= dt
        if self.shoot_timer > 0:
            return
        self.shoot_timer = random.uniform(0.15, 0.35)
        if not self.can_fire(game):
            return
        if self._aimed_at_target(game) or random.random() < 0.15:
            self.shoot(game)
            self.shoot_timer = random.uniform(ENEMY_SHOOT_MIN, ENEMY_SHOOT_MAX)

    def _aimed_at_target(self, game) -> bool:
        """Return True when the player or the base lies straight ahead."""
        row, col = self.row, self.col
        for target_row, target_col in (game.player.position, game.base_position):
            if self.direction == "up" and target_col == col and target_row < row:
                return True
            if self.direction == "down" and target_col == col and target_row > row:
                return True
            if self.direction == "left" and target_row == row and target_col < col:
                return True
            if self.direction == "right" and target_row == row and target_col > col:
                return True
        return False
