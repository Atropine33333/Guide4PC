"""Game state, rules and the real-time update loop."""

import random

from battlefield import (
    base_position, create_battlefield, enemy_spawn_points, in_bounds,
    is_tank_passable, player_spawn, walkable_cells,
)
from bullet import Bullet
from config import (
    BASE, BASE_RUBBLE, BRICK, DELTAS, ENEMY_BASE_TOTAL, ENEMY_TOTAL_CAP,
    ENEMY_TOTAL_PER_STAGE, EXTRA_LIFE_EVERY, FLOOR, FOREST, FREEZE_TIME,
    HIGH_SCORE_FILE, MAX_ENEMIES_ON_FIELD, PLAYER_LIVES, POWERUP_DROP_EVERY,
    POWERUP_SCORE, POWERUP_WEIGHTS, SHIELD_TIME, SPAWN_INTERVAL_BASE,
    SPAWN_INTERVAL_MIN, STAGE_CLEAR_BONUS, STATE_GAME_OVER, STATE_PAUSED,
    STATE_PLAYING, STATE_READY, STATE_STAGE_CLEAR, STEEL,
)
from enemy import Enemy
from player import Player
from powerup import PowerUp


def load_high_score() -> int:
    """Read the saved high score, ignoring a missing or broken file."""
    try:
        return int(HIGH_SCORE_FILE.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return 0


def save_high_score(score: int) -> None:
    """Best-effort persistence of the high score."""
    try:
        HIGH_SCORE_FILE.write_text(f"{score}\n", encoding="utf-8")
    except OSError:
        pass


class Effect:
    """A short-lived explosion or spark drawn on the battlefield."""

    def __init__(self, row: int, col: int, char: str, color: str,
                 ttl: float) -> None:
        self.row = row
        self.col = col
        self.char = char
        self.color = color
        self.ttl = ttl


class Game:
    """Owns all state and rules of a running tank battle."""

    def __init__(self) -> None:
        self.quit = False
        self.time = 0.0
        self.message = ""
        self.message_color = "bright_white"
        self.message_timer = 0.0
        self.high_score = load_high_score()
        self._reset_game()

    # ------------------------------------------------------------- lifecycle
    def _reset_game(self) -> None:
        self.score = 0
        self.lives = PLAYER_LIVES
        self.stage = 1
        self.next_extra_life = EXTRA_LIFE_EVERY
        self.over_reason = ""
        self._start_stage()

    def _start_stage(self) -> None:
        self.grid = create_battlefield(self.stage)
        spawn_row, spawn_col = player_spawn()
        self.player = Player(spawn_row, spawn_col)
        self.bullets: list[Bullet] = []
        self.enemies: list[Enemy] = []
        self.powerups: list[PowerUp] = []
        self.effects: list[Effect] = []
        self.freeze_time = 0.0
        self.kills_since_drop = 0
        self.spawn_queue = [self._pick_enemy_type()
                            for _ in range(self._enemy_total())]
        self.spawn_timer = 1.0
        self.state = STATE_READY
        self.timer = 1.8
        self.set_message(f"第 {self.stage} 关", "bright_yellow", 1.8)

    def set_message(self, text: str, color: str = "bright_white",
                    duration: float = 2.0) -> None:
        self.message = text
        self.message_color = color
        self.message_timer = duration

    # ------------------------------------------------------------------ input
    def handle_input(self, key: str) -> None:
        """React to one key press."""
        if key == "quit":
            self.quit = True
            return
        if key == "pause":
            if self.state == STATE_PLAYING:
                self.state = STATE_PAUSED
            elif self.state == STATE_PAUSED:
                self.state = STATE_PLAYING
            return
        if key in ("restart", "confirm") and self.state == STATE_GAME_OVER:
            self._reset_game()
            return
        if self.state == STATE_PLAYING and (key in DELTAS or key == "fire"):
            self.player.handle_key(key)

    # ----------------------------------------------------------------- update
    def update(self, dt: float) -> None:
        """Advance the whole game by *dt* seconds."""
        self.time += dt
        if self.message_timer > 0:
            self.message_timer -= dt
            if self.message_timer <= 0:
                self.message = ""
        if self.state == STATE_PAUSED:
            return

        self._update_effects(dt)

        if self.state == STATE_READY:
            self.timer -= dt
            if self.timer <= 0:
                self.state = STATE_PLAYING
                self.set_message("开始！", "bright_white", 1.0)
        elif self.state == STATE_STAGE_CLEAR:
            self.timer -= dt
            if self.timer <= 0:
                self.stage += 1
                self._start_stage()
        elif self.state == STATE_PLAYING:
            self._update_playing(dt)

    def _update_playing(self, dt: float) -> None:
        if self.freeze_time > 0:
            self.freeze_time = max(0.0, self.freeze_time - dt)

        self.player.update(dt, self)
        if self.state != STATE_PLAYING:
            return

        self._update_spawning(dt)
        for enemy in self.enemies:
            if enemy.alive:
                enemy.update(dt, self)
        if self.state != STATE_PLAYING:
            return

        self._update_bullets(dt)
        if self.state != STATE_PLAYING:
            return

        self._update_powerups(dt)
        self._remove_dead()
        self._update_extra_life()
        self._check_stage_clear()

    def _update_effects(self, dt: float) -> None:
        for effect in self.effects:
            effect.ttl -= dt
        self.effects = [e for e in self.effects if e.ttl > 0]

    # ---------------------------------------------------------------- spawning
    def _enemy_total(self) -> int:
        return min(
            ENEMY_TOTAL_CAP,
            ENEMY_BASE_TOTAL + ENEMY_TOTAL_PER_STAGE * (self.stage - 1),
        )

    def _pick_enemy_type(self) -> str:
        weights = {
            "basic": max(1, 8 - self.stage),
            "fast": 2 + self.stage,
            "power": 1 + self.stage // 2,
            "armor": max(0, self.stage - 1),
        }
        names = [name for name, weight in weights.items() if weight > 0]
        chances = [weights[name] for name in names]
        return random.choices(names, weights=chances, k=1)[0]

    def _update_spawning(self, dt: float) -> None:
        if not self.spawn_queue:
            return
        if sum(1 for e in self.enemies if e.alive) >= MAX_ENEMIES_ON_FIELD:
            return
        self.spawn_timer -= dt
        if self.spawn_timer > 0:
            return

        point = self._free_spawn_point()
        if point is None:
            self.spawn_timer = 0.3
            return

        type_name = self.spawn_queue.pop(0)
        self.enemies.append(Enemy(point[0], point[1], type_name))
        self._add_effect(point[0], point[1], "星", "bright_white", 0.4)
        interval = max(SPAWN_INTERVAL_MIN,
                       SPAWN_INTERVAL_BASE - 0.12 * self.stage)
        self.spawn_timer = interval * random.uniform(0.8, 1.2)

    def _free_spawn_point(self) -> tuple[int, int] | None:
        points = enemy_spawn_points()
        random.shuffle(points)
        for row, col in points:
            if self.can_tank_enter(None, row, col):
                return row, col
        return None

    def _find_respawn(self) -> tuple[int, int]:
        row, col = player_spawn()
        candidates = [(row, col), (row, col - 1), (row, col + 1),
                      (row - 1, col), (row, col - 2), (row + 1, col)]
        for r, c in candidates:
            if self.can_tank_enter(None, r, c):
                return r, c
        return row, col

    # ------------------------------------------------------------------ combat
    def can_tank_enter(self, tank, row: int, col: int) -> bool:
        """Return True if a tank may occupy the given tile."""
        if not in_bounds(row, col) or not is_tank_passable(self.grid[row][col]):
            return False
        for other in self.tanks():
            if other is not tank and other.alive and other.position == (row, col):
                return False
        return True

    def tanks(self):
        """Yield every living tank on the battlefield."""
        if self.player.alive:
            yield self.player
        yield from self.enemies

    def active_bullets(self, tank) -> int:
        """Number of live bullets owned by *tank*."""
        return sum(1 for b in self.bullets if b.alive and b.owner is tank)

    def spawn_bullet(self, tank) -> None:
        """Create a bullet for *tank* and resolve point-blank shots at once."""
        bullet = Bullet(tank.row, tank.col, tank.direction, tank,
                        tank.bullet_speed)
        self.bullets.append(bullet)
        tank.cooldown = tank.shoot_cooldown
        self._step_bullet(bullet)

    def _update_bullets(self, dt: float) -> None:
        for bullet in self.bullets:
            if not bullet.alive:
                continue
            bullet.accum += dt
            while bullet.alive and bullet.accum >= bullet.interval:
                bullet.accum -= bullet.interval
                self._step_bullet(bullet)
        self._resolve_bullet_duels()

    def _step_bullet(self, bullet: Bullet) -> None:
        dr, dc = DELTAS[bullet.direction]
        bullet.row += dr
        bullet.col += dc
        if not in_bounds(bullet.row, bullet.col):
            bullet.alive = False
            return

        tile = self.grid[bullet.row][bullet.col]
        if tile == BRICK:
            self.grid[bullet.row][bullet.col] = FLOOR
            self._add_effect(bullet.row, bullet.col, "碎", "yellow", 0.12)
            bullet.alive = False
            return
        if tile == STEEL:
            if bullet.breaks_steel:
                self.grid[bullet.row][bullet.col] = FLOOR
                self._add_effect(bullet.row, bullet.col, "碎",
                                 "bright_white", 0.12)
            bullet.alive = False
            return
        if tile == BASE:
            bullet.alive = False
            self._destroy_base(bullet.faction == "player")
            return

        # Water, forest, floor and rubble do not stop bullets.
        if bullet.faction == "player":
            for enemy in self.enemies:
                if enemy.alive and enemy.position == bullet.position:
                    bullet.alive = False
                    enemy.take_damage()
                    if not enemy.alive:
                        self._kill_enemy(enemy)
                    return
        else:
            if self.player.alive and self.player.position == bullet.position:
                bullet.alive = False
                self._hit_player()

    def _resolve_bullet_duels(self) -> None:
        for index, first in enumerate(self.bullets):
            if not first.alive:
                continue
            for second in self.bullets[index + 1:]:
                if (second.alive and first.faction != second.faction
                        and first.position == second.position):
                    first.alive = False
                    second.alive = False
                    self._add_effect(first.row, first.col, "火",
                                     "bright_yellow", 0.12)
                    break

    # ------------------------------------------------------------------ damage
    def _kill_enemy(self, enemy: Enemy) -> None:
        self.score += enemy.score
        self._add_effect(enemy.row, enemy.col, "爆", "bright_red", 0.3)
        self.kills_since_drop += 1
        if self.kills_since_drop >= POWERUP_DROP_EVERY:
            self.kills_since_drop = 0
            self._drop_powerup()

    def _hit_player(self) -> None:
        player = self.player
        if not player.alive or player.shield_time > 0:
            return
        self._add_effect(player.row, player.col, "爆", "bright_yellow", 0.45)
        for bullet in self.bullets:
            if bullet.faction == "player":
                bullet.alive = False
        self.lives -= 1
        if self.lives <= 0:
            player.alive = False
            self._game_over("你的坦克全部被击毁")
            return
        row, col = self._find_respawn()
        self.player = Player(row, col)
        self.set_message(f"被击中！剩余生命 {self.lives}", "bright_red")

    def _destroy_base(self, by_player: bool) -> None:
        row, col = base_position()
        self.grid[row][col] = BASE_RUBBLE
        self._add_effect(row, col, "爆", "bright_yellow", 0.8)
        reason = "基地被自己的炮火摧毁了…" if by_player else "基地被敌人摧毁了"
        self._game_over(reason)

    def _game_over(self, reason: str) -> None:
        if self.state == STATE_GAME_OVER:
            return
        self.state = STATE_GAME_OVER
        self.over_reason = reason
        if self.score > self.high_score:
            self.high_score = self.score
        save_high_score(self.high_score)

    def _remove_dead(self) -> None:
        self.enemies = [e for e in self.enemies if e.alive]
        self.bullets = [b for b in self.bullets if b.alive]

    # ------------------------------------------------------------------ items
    def _drop_powerup(self) -> None:
        base_row, base_col = base_position()
        cells = [
            (r, c) for r, c in walkable_cells(self.grid)
            if self.grid[r][c] in (FLOOR, FOREST)
            and not any(t.alive and t.position == (r, c) for t in self.tanks())
            and not any(p.position == (r, c) for p in self.powerups)
            and abs(r - base_row) + abs(c - base_col) > 4
        ]
        if not cells:
            return
        row, col = random.choice(cells)
        names = list(POWERUP_WEIGHTS)
        kind = random.choices(names, weights=[POWERUP_WEIGHTS[n] for n in names],
                              k=1)[0]
        self.powerups.append(PowerUp(kind, row, col))
        self.set_message("敌人掉落了道具！", "bright_yellow", 1.5)

    def _update_powerups(self, dt: float) -> None:
        for powerup in list(self.powerups):
            powerup.ttl -= dt
            if powerup.ttl <= 0:
                self.powerups.remove(powerup)
                continue
            if self.player.alive and self.player.position == (powerup.row,
                                                              powerup.col):
                self.powerups.remove(powerup)
                self._collect(powerup)

    def _collect(self, powerup: PowerUp) -> None:
        self.score += POWERUP_SCORE
        kind = powerup.kind
        if kind == "star":
            self.player.power = min(3, self.player.power + 1)
            self.set_message(f"火力提升到 {self.player.power + 1} 级！",
                             "bright_yellow")
        elif kind == "bomb":
            for enemy in self.enemies:
                if enemy.alive:
                    self.score += enemy.score
                    self._add_effect(enemy.row, enemy.col, "爆",
                                     "bright_red", 0.3)
                    enemy.hp = 0
                    enemy.alive = False
            self.set_message("全屏爆破！", "bright_red")
        elif kind == "shield":
            self.player.shield_time = SHIELD_TIME
            self.set_message("获得护盾！", "bright_cyan")
        elif kind == "life":
            self.lives += 1
            self.set_message("获得额外生命！", "bright_green")
        elif kind == "clock":
            self.freeze_time = FREEZE_TIME
            self.set_message("敌人被冻结！", "bright_blue")

    def _update_extra_life(self) -> None:
        while self.score >= self.next_extra_life:
            self.lives += 1
            self.next_extra_life += EXTRA_LIFE_EVERY
            self.set_message("奖励生命 +1", "bright_green")

    # ------------------------------------------------------------------ state
    def _check_stage_clear(self) -> None:
        if self.enemies or self.spawn_queue:
            return
        self.state = STATE_STAGE_CLEAR
        self.timer = 2.2
        bonus = STAGE_CLEAR_BONUS * self.stage
        self.score += bonus
        self.set_message(f"第 {self.stage} 关完成，奖励 {bonus} 分",
                         "bright_green")

    def _add_effect(self, row: int, col: int, char: str, color: str,
                    ttl: float) -> None:
        self.effects.append(Effect(row, col, char, color, ttl))

    # ---------------------------------------------------------------- helpers
    @property
    def base_position(self) -> tuple[int, int]:
        return base_position()

    @property
    def enemies_remaining(self) -> int:
        return len(self.spawn_queue) + sum(1 for e in self.enemies if e.alive)

    def save_high_score(self) -> None:
        if self.score > self.high_score:
            self.high_score = self.score
        save_high_score(self.high_score)
