#!/usr/bin/env python3
"""坦克大战 - 终端实时版入口。

运行:
    python3 main.py

操作:
    WASD / 方向键    移动
    J / 空格         开火
    P                暂停
    R                游戏结束后重新开始
    Q                退出
"""

import shutil
import signal
import sys
import time

from config import (
    FRAME_TIME, INPUT_POLL_SLEEP, LOGIC_STEP, MIN_COLS, MIN_LINES,
    STATE_GAME_OVER,
)
from display import Renderer, render_frame
from game import Game
from input_handler import InputHandler


def _install_signal_handlers() -> None:
    """Make sure the terminal is restored when the process is killed."""

    def _handler(signum, frame):
        raise KeyboardInterrupt

    for name in ("SIGINT", "SIGTERM"):
        sig = getattr(signal, name, None)
        if sig is None:
            continue
        try:
            signal.signal(sig, _handler)
        except (ValueError, OSError):
            pass


def _too_small_message() -> str:
    size = shutil.get_terminal_size((80, 24))
    return (f"请把终端窗口放大到至少 {MIN_COLS} 列 x {MIN_LINES} 行"
            f"（当前 {size.columns} x {size.lines}）")


def main() -> None:
    """Run the game until the player quits."""
    if not sys.stdin.isatty():
        print("请在交互式终端中运行本游戏（需要实时读取按键）。")
        return

    _install_signal_handlers()
    game = Game()
    renderer = Renderer()

    try:
        with InputHandler() as keys:
            renderer.start()
            try:
                last = time.perf_counter()
                accumulator = 0.0
                next_frame = last
                while not game.quit:
                    now = time.perf_counter()
                    for key in keys.read_keys():
                        game.handle_input(key)

                    # Fixed-step simulation, independent of render speed.
                    accumulator += min(now - last, 0.25)
                    last = now
                    while accumulator >= LOGIC_STEP:
                        game.update(LOGIC_STEP)
                        accumulator -= LOGIC_STEP

                    if now >= next_frame:
                        size = shutil.get_terminal_size((80, 24))
                        if (size.columns < MIN_COLS
                                or size.lines < MIN_LINES):
                            renderer.draw([_too_small_message()])
                        else:
                            renderer.draw(render_frame(game))
                        next_frame = now + FRAME_TIME

                    time.sleep(INPUT_POLL_SLEEP)
            finally:
                renderer.stop()
    except KeyboardInterrupt:
        pass

    game.save_high_score()
    if game.state == STATE_GAME_OVER:
        print(f"本局得分 {game.score}，最高分 {game.high_score}。")
    else:
        print(f"退出游戏，本局得分 {game.score}，最高分 {game.high_score}。")


if __name__ == "__main__":
    main()
