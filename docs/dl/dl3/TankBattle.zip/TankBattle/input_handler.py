"""Non-blocking keyboard input for Windows and Unix terminals."""

import os
import select
import sys
import time

# Characters that map to game actions.
_KEY_CHARS = {
    "w": "up", "a": "left", "s": "down", "d": "right",
    "j": "fire", " ": "fire",
    "p": "pause",
    "q": "quit",
    "r": "restart",
    "\r": "confirm", "\n": "confirm",
    "\x03": "quit",          # Ctrl+C inside a raw terminal
}
_ARROW_CODES = {"A": "up", "B": "down", "C": "right", "D": "left"}
_WINDOWS_ARROWS = {"H": "up", "P": "down", "K": "left", "M": "right"}
_ESCAPE_GRACE = 0.12         # seconds before a lone ESC counts as a key


def parse_keys(buffer: str, now: float, last_data: float) -> tuple[list[str], str]:
    """Split *buffer* into key names, keeping incomplete escapes buffered.

    Args:
        buffer: Bytes decoded as text that have not been consumed yet.
        now: Current monotonic time.
        last_data: Monotonic time when input last arrived.

    Returns:
        (key names, remaining buffer)
    """
    keys: list[str] = []
    index = 0
    while index < len(buffer):
        char = buffer[index]
        if char == "\x1b":
            rest = buffer[index:]
            if rest.startswith("\x1b["):
                if len(rest) < 3:
                    break                      # wait for the rest of the escape
                code = rest[2]
                if code in _ARROW_CODES:
                    keys.append(_ARROW_CODES[code])
                    index += 3
                    continue
                final = 2
                while final < len(rest) and not ("@" <= rest[final] <= "~"):
                    final += 1
                index += final + 1
                continue
            if index == len(buffer) - 1:
                if now - last_data > _ESCAPE_GRACE:
                    keys.append("pause")
                    index += 1
                break                          # maybe an escape in progress
            index += 1
            continue
        action = _KEY_CHARS.get(char.lower())
        if action:
            keys.append(action)
        index += 1
    return keys, buffer[index:]


class InputHandler:
    """Puts the terminal in raw mode and polls it without blocking."""

    def __enter__(self) -> "InputHandler":
        self._buffer = ""
        self._last_data = time.monotonic()
        if os.name == "nt":
            import msvcrt

            self._msvcrt = msvcrt
        else:
            import termios
            import tty

            self._termios = termios
            self._fd = sys.stdin.fileno()
            self._old_settings = termios.tcgetattr(self._fd)
            tty.setraw(self._fd)
        return self

    def __exit__(self, exc_type, exc, traceback) -> bool:
        if os.name != "nt":
            self._termios.tcsetattr(self._fd, self._termios.TCSADRAIN,
                                    self._old_settings)
        return False

    def read_keys(self) -> list[str]:
        """Return every key pressed since the previous call."""
        if os.name == "nt":
            return self._read_windows()
        return self._read_unix()

    def _read_unix(self) -> list[str]:
        data = ""
        while select.select([sys.stdin], [], [], 0)[0]:
            chunk = os.read(self._fd, 64)
            if not chunk:
                break
            data += chunk.decode("utf-8", errors="ignore")
            self._last_data = time.monotonic()
        self._buffer += data
        keys, self._buffer = parse_keys(self._buffer, time.monotonic(),
                                        self._last_data)
        return keys

    def _read_windows(self) -> list[str]:
        keys: list[str] = []
        while self._msvcrt.kbhit():
            char = self._msvcrt.getwch()
            if char in ("\x00", "\xe0"):
                if self._msvcrt.kbhit():
                    code = self._msvcrt.getwch()
                    action = _WINDOWS_ARROWS.get(code)
                    if action:
                        keys.append(action)
                continue
            action = _KEY_CHARS.get(char.lower())
            if action:
                keys.append(action)
        return keys
