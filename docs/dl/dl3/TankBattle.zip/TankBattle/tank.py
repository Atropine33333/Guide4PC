"""Base tank class shared by the player and enemy tanks."""

from config import DELTAS, DIRECTION_MARKS


class Tank:
    """Base class for every tank on the battlefield.

    Attributes:
        row, col: Current tile.
        direction: One of 'up', 'down', 'left', 'right'.
        char: Display character.
        color: Display color name.
        hp, max_hp: Hit points.
        faction: 'player' or 'enemy'.
        alive: False once the tank is destroyed.
    """

    # Defaults; subclasses may override them with properties.
    bullet_speed = 1.0
    max_bullets = 1
    shoot_cooldown = 0.3
    breaks_steel = False

    def __init__(self, row: int, col: int, char: str, color: str, hp: int,
                 move_interval: float, faction: str) -> None:
        self.row = row
        self.col = col
        self.direction = "up"
        self.char = char
        self.color = color
        self.hp = hp
        self.max_hp = hp
        self.move_interval = move_interval
        self.faction = faction
        self.alive = True
        self.cooldown = 0.0
        self.move_accum = 0.0

    @property
    def position(self) -> tuple[int, int]:
        """Return (row, col)."""
        return self.row, self.col

    def mark(self) -> str:
        """Return the ASCII marker used to show the facing direction."""
        return DIRECTION_MARKS[self.direction]

    def try_move(self, direction: str, game) -> bool:
        """Turn towards *direction* and move one tile when possible.

        Returns:
            bool: True if the tank actually moved.
        """
        self.direction = direction
        dr, dc = DELTAS[direction]
        new_row, new_col = self.row + dr, self.col + dc
        if game.can_tank_enter(self, new_row, new_col):
            self.row = new_row
            self.col = new_col
            return True
        return False

    def take_damage(self, amount: int = 1) -> None:
        """Reduce HP; the tank dies when HP reaches zero."""
        self.hp = max(0, self.hp - amount)
        if self.hp == 0:
            self.alive = False

    def can_fire(self, game) -> bool:
        """Return True if the tank may fire right now."""
        if self.cooldown > 0:
            return False
        return game.active_bullets(self) < self.max_bullets

    def shoot(self, game) -> None:
        """Ask the game to create a bullet for this tank."""
        game.spawn_bullet(self)
