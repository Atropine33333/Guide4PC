"""Global configuration for the terminal tank battle game."""

from pathlib import Path

# ------------------------------------------------------------------ timing
FRAME_TIME = 1 / 60          # target seconds per rendered frame
LOGIC_STEP = 1 / 120         # fixed simulation step
INPUT_POLL_SLEEP = 0.002     # seconds between input polls in the main loop
TAP_HOLD_TIMEOUT = 0.15      # keep moving briefly after a tap
HOLD_TIMEOUT_MIN = 0.09      # timeout once the key repeat cadence is known
HOLD_GRACE_MAX = 0.60        # cap for the adaptive hold timeout
REPEAT_MAX_GAP = 0.45        # larger gaps are treated as a fresh key press
FIRE_HOLD_TIMEOUT = 0.15     # keep trying to fire after the last key event

# ------------------------------------------------------------- battlefield
FIELD_WIDTH = 26             # logical tiles per row
FIELD_HEIGHT = 16            # logical rows
CELL_WIDTH = 3               # terminal columns used by one tile
MIN_COLS = FIELD_WIDTH * CELL_WIDTH     # 78
MIN_LINES = FIELD_HEIGHT + 3            # 19

# Tile kinds
FLOOR = "floor"
BRICK = "brick"
STEEL = "steel"
WATER = "water"
FOREST = "forest"
BASE = "base"
BASE_RUBBLE = "base_rubble"

# Terrain glyphs are drawn inside a CELL_WIDTH wide cell: a Chinese
# character is two columns wide, so it is padded with one space.
TERRAIN_GLYPHS = {
    FLOOR: " ",
    BRICK: "砖",
    STEEL: "钢",
    WATER: "水",
    FOREST: "林",
    BASE: "鹰",
    BASE_RUBBLE: "毁",
}

TERRAIN_COLORS = {
    FLOOR: None,
    BRICK: "yellow",
    STEEL: "bright_white",
    WATER: "bright_blue",
    FOREST: "green",
    BASE: "bright_yellow",
    BASE_RUBBLE: "bright_red",
}

# ------------------------------------------------------------------ entities
PLAYER_CHAR = "我"
PLAYER_COLOR = "bright_green"
DIRECTION_MARKS = {"up": "^", "down": "v", "left": "<", "right": ">"}
DIRECTIONS = ("up", "down", "left", "right")
DELTAS = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}
OPPOSITE = {"up": "down", "down": "up", "left": "right", "right": "left"}

ENEMY_TYPES = {
    "basic": {"char": "敌", "color": "red",
              "hp": 1, "speed": 1.0, "bullet_speed": 1.0, "score": 100},
    "fast":  {"char": "快", "color": "bright_cyan",
              "hp": 1, "speed": 1.8, "bullet_speed": 1.0, "score": 200},
    "power": {"char": "猛", "color": "magenta",
              "hp": 1, "speed": 1.0, "bullet_speed": 2.0, "score": 300},
    "armor": {"char": "甲", "color": "bright_yellow",
              "hp": 4, "speed": 0.7, "bullet_speed": 1.0, "score": 400},
}
# Armour tanks change color as they lose plating.
ARMOR_HP_COLORS = {4: "bright_yellow", 3: "yellow", 2: "red", 1: "gray"}

BULLET_GLYPH = "•"
BULLET_COLORS = {"player": "bright_yellow", "enemy": "bright_red"}

# ------------------------------------------------------------------ combat
PLAYER_MOVE_INTERVAL = 0.11      # seconds per tile
PLAYER_SHOOT_COOLDOWN = 0.28
BULLET_MOVE_INTERVAL = 0.040     # seconds per tile at speed 1.0
ENEMY_MOVE_INTERVAL = 0.26       # base interval, divided by type speed
ENEMY_SHOOT_MIN = 0.90
ENEMY_SHOOT_MAX = 1.80

# Power level 0..3: more bullets, faster bullets, steel breaking.
PLAYER_BULLETS_BY_POWER = (1, 1, 2, 2)
PLAYER_BULLET_SPEED_BY_POWER = (1.0, 1.6, 1.6, 2.0)

PLAYER_LIVES = 3
SPAWN_SHIELD_TIME = 3.0          # invincibility after spawning
SHIELD_TIME = 8.0                # invincibility from a power-up
FREEZE_TIME = 6.0                # enemies frozen by a power-up

# ------------------------------------------------------------------ enemies
MAX_ENEMIES_ON_FIELD = 4
ENEMY_BASE_TOTAL = 10            # enemies in stage 1
ENEMY_TOTAL_PER_STAGE = 2        # extra enemies per later stage
ENEMY_TOTAL_CAP = 20
SPAWN_INTERVAL_BASE = 3.0
SPAWN_INTERVAL_MIN = 1.0

# ------------------------------------------------------------------ power-ups
POWERUP_LIFETIME = 12.0
POWERUP_DROP_EVERY = 4           # kills needed before an item drops
POWERUP_SCORE = 500
POWERUP_TYPES = {
    "star":   {"glyph": "星", "color": "bright_yellow"},
    "bomb":   {"glyph": "炸", "color": "bright_red"},
    "shield": {"glyph": "盾", "color": "bright_cyan"},
    "life":   {"glyph": "命", "color": "bright_green"},
    "clock":  {"glyph": "钟", "color": "bright_blue"},
}
POWERUP_WEIGHTS = {"star": 3, "bomb": 2, "shield": 2, "life": 1, "clock": 2}

# ------------------------------------------------------------------ scoring
STAGE_CLEAR_BONUS = 500
EXTRA_LIFE_EVERY = 5000

# ------------------------------------------------------------------ game states
STATE_READY = "ready"
STATE_PLAYING = "playing"
STATE_PAUSED = "paused"
STATE_STAGE_CLEAR = "stage_clear"
STATE_GAME_OVER = "game_over"

# ------------------------------------------------------------------ colors
COLORS = {
    "reset": "\033[0m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
    "white": "\033[37m",
    "gray": "\033[90m",
    "bright_red": "\033[91m",
    "bright_green": "\033[92m",
    "bright_yellow": "\033[93m",
    "bright_blue": "\033[94m",
    "bright_magenta": "\033[95m",
    "bright_cyan": "\033[96m",
    "bright_white": "\033[97m",
}

# ------------------------------------------------------------------ misc
GAME_TITLE = "坦克大战"
HIGH_SCORE_FILE = Path(__file__).resolve().parent / "highscore.txt"
