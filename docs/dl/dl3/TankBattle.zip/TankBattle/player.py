"""Player-controlled tank."""

from config import (
    DELTAS, FIRE_HOLD_TIMEOUT, HOLD_GRACE_MAX, HOLD_TIMEOUT_MIN,
    PLAYER_BULLETS_BY_POWER, PLAYER_BULLET_SPEED_BY_POWER, PLAYER_CHAR,
    PLAYER_COLOR, PLAYER_MOVE_INTERVAL, PLAYER_SHOOT_COOLDOWN,
    REPEAT_MAX_GAP, SPAWN_SHIELD_TIME, TAP_HOLD_TIMEOUT,
)
from tank import Tank


class Player(Tank):
    """The player tank: moves in real time and fires on demand."""

    def __init__(self, row: int, col: int) -> None:
        super().__init__(
            row, col, PLAYER_CHAR, PLAYER_COLOR,
            hp=1, move_interval=PLAYER_MOVE_INTERVAL, faction="player",
        )
        self.power = 0                 # 0..3, raised by star power-ups
        self.shield_time = SPAWN_SHIELD_TIME
        self.held_direction = None
        self.held_timer = 0.0
        self.fire_held = False
        self.fire_timer = 0.0
        self.shoot_cooldown = PLAYER_SHOOT_COOLDOWN
        self._clock = 0.0
        self._last_event = -10.0
        self._repeat_gap = None

    @property
    def max_bullets(self) -> int:
        return PLAYER_BULLETS_BY_POWER[self.power]

    @property
    def bullet_speed(self) -> float:
        return PLAYER_BULLET_SPEED_BY_POWER[self.power]

    @property
    def breaks_steel(self) -> bool:
        return self.power >= 3

    def handle_key(self, key: str) -> None:
        """Remember a direction or the fire key (called on key events)."""
        if key in DELTAS:
            gap = self._clock - self._last_event
            if key == self.held_direction and gap < REPEAT_MAX_GAP:
                # Auto-repeat of a held key: once the terminal's repeat
                # cadence is known the tank stops within one tile after
                # the key is released.
                if self._repeat_gap is None:
                    self._repeat_gap = gap
                else:
                    self._repeat_gap = min(self._repeat_gap, gap)
                self.held_timer = max(
                    HOLD_TIMEOUT_MIN,
                    min(HOLD_GRACE_MAX, self._repeat_gap * 2.5),
                )
            else:
                # A fresh direction reacts with an immediate step.
                if key != self.held_direction:
                    self.move_accum = self.move_interval
                self.held_timer = TAP_HOLD_TIMEOUT
            self._last_event = self._clock
            self.held_direction = key
        elif key == "fire":
            self.fire_held = True
            self.fire_timer = FIRE_HOLD_TIMEOUT

    def update(self, dt: float, game) -> None:
        """Advance movement, shields and shooting by *dt* seconds."""
        self._clock += dt
        self.cooldown = max(0.0, self.cooldown - dt)
        self.shield_time = max(0.0, self.shield_time - dt)

        self.held_timer -= dt
        if self.held_timer <= 0:
            self.held_direction = None

        self.fire_timer -= dt
        if self.fire_timer <= 0:
            self.fire_held = False

        if self.held_direction:
            self.direction = self.held_direction
            self.move_accum += dt
            while self.move_accum >= self.move_interval:
                self.move_accum -= self.move_interval
                self.try_move(self.direction, game)
        else:
            self.move_accum = 0.0

        if self.fire_held and self.can_fire(game):
            self.shoot(game)
