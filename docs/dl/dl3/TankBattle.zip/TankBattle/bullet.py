"""Bullets fired by tanks."""

from config import BULLET_MOVE_INTERVAL


class Bullet:
    """A projectile that flies one tile per interval and never turns."""

    def __init__(self, row: int, col: int, direction: str, owner,
                 speed: float = 1.0) -> None:
        self.row = row
        self.col = col
        self.direction = direction
        self.owner = owner
        self.faction = owner.faction
        self.breaks_steel = owner.breaks_steel
        self.interval = BULLET_MOVE_INTERVAL / speed
        self.accum = 0.0
        self.alive = True

    @property
    def position(self) -> tuple[int, int]:
        """Return (row, col)."""
        return self.row, self.col
