"""Battlefield generation and terrain queries."""

import random

from config import (
    BASE, BASE_RUBBLE, BRICK, FIELD_HEIGHT, FIELD_WIDTH, FLOOR, FOREST,
    STEEL, WATER,
)


def in_bounds(row: int, col: int) -> bool:
    """Return True if (row, col) is inside the battlefield."""
    return 0 <= row < FIELD_HEIGHT and 0 <= col < FIELD_WIDTH


def is_tank_passable(tile: str) -> bool:
    """Return True if tanks may drive onto this tile."""
    return tile in (FLOOR, FOREST, BASE_RUBBLE)


def base_position() -> tuple[int, int]:
    """Return the tile of the eagle base (bottom centre)."""
    return FIELD_HEIGHT - 2, FIELD_WIDTH // 2


def player_spawn() -> tuple[int, int]:
    """Return the tile where the player tank starts."""
    return FIELD_HEIGHT - 2, FIELD_WIDTH // 2 - 3


def enemy_spawn_points() -> list[tuple[int, int]]:
    """Return the three enemy spawn tiles on the top row."""
    return [(1, 1), (1, FIELD_WIDTH // 2), (1, FIELD_WIDTH - 2)]


def create_battlefield(stage: int) -> list[list[str]]:
    """Build the terrain grid for a stage.

    Args:
        stage: 1-based stage number, used to scale difficulty.

    Returns:
        A FIELD_HEIGHT x FIELD_WIDTH grid of tile names.
    """
    grid = [[FLOOR] * FIELD_WIDTH for _ in range(FIELD_HEIGHT)]
    _add_border(grid)
    _add_brick_blocks(grid, stage)
    _add_steel_blocks(grid, stage)
    _add_water(grid, stage)
    _add_forest(grid)
    _build_base(grid)
    _clear_spawn_zones(grid)
    return grid


def walkable_cells(grid: list[list[str]]) -> list[tuple[int, int]]:
    """Return every interior tile a tank can stand on."""
    return [
        (r, c)
        for r in range(1, FIELD_HEIGHT - 1)
        for c in range(1, FIELD_WIDTH - 1)
        if is_tank_passable(grid[r][c])
    ]


# ------------------------------------------------------------------ internals
def _add_border(grid: list[list[str]]) -> None:
    """Surround the battlefield with indestructible steel."""
    for c in range(FIELD_WIDTH):
        grid[0][c] = STEEL
        grid[FIELD_HEIGHT - 1][c] = STEEL
    for r in range(FIELD_HEIGHT):
        grid[r][0] = STEEL
        grid[r][FIELD_WIDTH - 1] = STEEL


def _fill(grid, row: int, col: int, height: int, width: int, tile: str) -> None:
    for r in range(row, min(row + height, FIELD_HEIGHT)):
        for c in range(col, min(col + width, FIELD_WIDTH)):
            grid[r][c] = tile


def _area_is_floor(grid, row: int, col: int, height: int, width: int) -> bool:
    for r in range(row, row + height):
        for c in range(col, col + width):
            if not in_bounds(r, c) or grid[r][c] != FLOOR:
                return False
    return True


def _find_blank_area(grid, height: int, width: int,
                     row_range: tuple[int, int],
                     col_range: tuple[int, int]) -> tuple[int, int] | None:
    for _ in range(80):
        row = random.randint(*row_range)
        col = random.randint(*col_range)
        if _area_is_floor(grid, row, col, height, width):
            return row, col
    return None


def _add_brick_blocks(grid, stage: int) -> None:
    """Scatter 2x2 brick blocks like the arcade maps."""
    density = min(0.32 + 0.05 * stage, 0.60)
    spots = [
        (r, c)
        for r in range(2, FIELD_HEIGHT - 4, 3)
        for c in range(3, FIELD_WIDTH - 4, 4)
    ]
    random.shuffle(spots)
    for row, col in spots:
        if random.random() < density:
            _fill(grid, row, col, 2, 2, BRICK)


def _add_steel_blocks(grid, stage: int) -> None:
    """Add a few 2x2 steel blocks."""
    wanted = min(1 + stage // 2, 4)
    spots = [
        (r, c)
        for r in range(3, FIELD_HEIGHT - 5, 3)
        for c in range(5, FIELD_WIDTH - 5, 5)
    ]
    random.shuffle(spots)
    placed = 0
    for row, col in spots:
        if placed >= wanted:
            break
        if not _area_is_floor(grid, row, col, 2, 2):
            continue
        _fill(grid, row, col, 2, 2, STEEL)
        placed += 1


def _add_water(grid, stage: int) -> None:
    """Add ponds that block tanks but not bullets."""
    if stage < 2:
        return
    for _ in range(random.randint(1, 2)):
        spot = _find_blank_area(
            grid, 2, 3,
            (4, FIELD_HEIGHT - 7),
            (3, FIELD_WIDTH - 6),
        )
        if spot:
            _fill(grid, spot[0], spot[1], 2, 3, WATER)


def _add_forest(grid) -> None:
    """Add a small forest patch that hides enemy tanks."""
    spot = _find_blank_area(
        grid, 2, 3,
        (3, FIELD_HEIGHT - 7),
        (3, FIELD_WIDTH - 6),
    )
    if spot:
        _fill(grid, spot[0], spot[1], 2, 3, FOREST)


def _build_base(grid) -> None:
    """Clear the home area, then build the eagle and its brick shield."""
    base_row, base_col = base_position()
    for r in range(base_row - 2, base_row + 1):
        for c in range(base_col - 5, base_col + 3):
            if in_bounds(r, c):
                grid[r][c] = FLOOR

    grid[base_row][base_col] = BASE
    shield = (
        (base_row - 1, base_col - 1), (base_row - 1, base_col),
        (base_row - 1, base_col + 1), (base_row, base_col - 1),
        (base_row, base_col + 1),
    )
    for row, col in shield:
        grid[row][col] = BRICK


def _clear_spawn_zones(grid) -> None:
    """Keep the enemy spawns and the player spawn free of terrain."""
    for row, col in enemy_spawn_points():
        for r in range(row, row + 2):
            for c in range(max(1, col - 1), min(FIELD_WIDTH - 1, col + 2)):
                grid[r][c] = FLOOR

    spawn_row, spawn_col = player_spawn()
    for r in range(spawn_row - 2, spawn_row + 1):
        for c in range(spawn_col - 1, spawn_col + 2):
            if in_bounds(r, c):
                grid[r][c] = FLOOR
