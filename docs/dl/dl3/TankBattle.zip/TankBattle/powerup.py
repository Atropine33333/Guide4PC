"""Collectible power-ups dropped by destroyed enemies."""

from config import POWERUP_LIFETIME


class PowerUp:
    """An item the player can collect by driving over it."""

    def __init__(self, kind: str, row: int, col: int) -> None:
        self.kind = kind
        self.row = row
        self.col = col
        self.ttl = POWERUP_LIFETIME

    @property
    def position(self) -> tuple[int, int]:
        """Return (row, col)."""
        return self.row, self.col
