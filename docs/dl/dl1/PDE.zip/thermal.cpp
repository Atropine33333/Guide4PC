/**
 * @file main.cpp
 * @brief 2D transient heat conduction inverse problem using finite-difference
 *        perturbation (DeepFDM philosophy).  Multi‑time loss, RMSprop, and
 *        spatial sensitivity tuning recover a hidden low‑conductivity region.
 *
 * Physics:
 *   ∂T/∂t = α(x,y)·∇²T + S(x,y)   (convection disabled for clarity)
 *
 * Domain: [0,1]×[0,0.5] m,  NX=40, NY=20,  Dirichlet T=0 on all boundaries.
 *
 * TRUE FIELD:  left half  (x < 0.5) → α = 0.1  (insulating air gap)
 *              right half (x ≥ 0.5) → α = 0.8  (copper)
 * Source: Gaussian centred at (0.3,0.25) with amplitude 500.
 *
 * The source lies inside the low‑α region, making the inverse problem well‑posed.
 *
 * Forward solver:  explicit Euler, fixed 3×3 Laplacian kernel, upwind (unused).
 * Inverse solver:  central finite‑difference gradient, RMSprop, multi‑time
 *                  mean‑squared‑error loss, gradient clipping.
 *
 * Compilation:  g++ -std=c++17 -O2 -fopenmp main.cpp -o thermal
 */

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <omp.h>

// -----------------------------------------------------------------------------
// Global log stream – writes to both console and file "inversion.log"
// -----------------------------------------------------------------------------
std::ofstream g_logfile;  ///< Output file for all logging messages

/**
 * @brief Write a message to both std::cout and the global log file.
 * @param msg  Message string (without trailing newline; a newline is appended).
 */
inline void log_write(const std::string& msg) {
    std::cout << msg << std::endl;
    if (g_logfile.is_open()) g_logfile << msg << std::endl;
}

// =============================================================================
// Class Grid2D : 2D data container (row‑major)
// =============================================================================
class Grid2D {
public:
    int nx, ny;                 ///< Grid dimensions
    std::vector<double> data;   ///< Row‑major storage: index = j * nx + i

    /**
     * @brief Construct a zero‑filled grid.
     * @param nx_  Number of points in x direction
     * @param ny_  Number of points in y direction
     */
    Grid2D(int nx_ = 0, int ny_ = 0) : nx(nx_), ny(ny_), data(nx_ * ny_, 0.0) {}

    /// Element access (i = x-index, j = y-index)
    double& at(int i, int j) { return data[j * nx + i]; }
    /// Const element access
    const double& at(int i, int j) const { return data[j * nx + i]; }

    /**
     * @brief Set all four boundary rows/columns to a constant (Dirichlet BC).
     */
    void setBoundary(double value) {
        for (int i = 0; i < nx; ++i) {
            at(i, 0) = value;          // bottom
            at(i, ny - 1) = value;     // top
        }
        for (int j = 0; j < ny; ++j) {
            at(0, j) = value;          // left
            at(nx - 1, j) = value;     // right
        }
    }

    /// Deep copy from another Grid2D of the same size.
    void copyFrom(const Grid2D& other) {
        std::copy(other.data.begin(), other.data.end(), data.begin());
    }
};

// =============================================================================
// Class HeatSolver : forward PDE engine
// =============================================================================
class HeatSolver {
public:
    double dx, dy, dt;   ///< Spatial steps and current time step

    /**
     * @brief Constructor storing spatial steps and an initial time step.
     */
    HeatSolver(double dx_, double dy_, double dt_)
        : dx(dx_), dy(dy_), dt(dt_) {}

    /// Update the time step (used to satisfy the CFL condition).
    void setDt(double new_dt) { dt = new_dt; }

    /**
     * @brief Advance temperature by one explicit Euler step.
     *
     * **DeepFDM physical prior:**
     * - Laplacian is computed with a **fixed 3×3 kernel** `[[0,1,0],[1,-4,1],[0,1,0]] / dx²`.
     * - Convection uses **upwind** differencing.
     * - A double‑buffer (T_old) guarantees that T^{n+1} depends only on T^n.
     */
    void stepForward(Grid2D& T, const Grid2D& Alpha, const Grid2D& Source,
                     double vx, double vy) {
        Grid2D T_old = T;   // deep copy – essential for explicit Euler

        for (int j = 1; j < T.ny - 1; ++j) {
            for (int i = 1; i < T.nx - 1; ++i) {
                // ---- Fixed Laplacian (physical prior) ----
                double lap = (T_old.at(i-1,j) + T_old.at(i+1,j) +
                              T_old.at(i,j-1) + T_old.at(i,j+1) -
                              4.0 * T_old.at(i,j)) / (dx * dx);

                // ---- Upwind x-gradient ----
                double dTx = (vx >= 0.0)
                                 ? (T_old.at(i,j) - T_old.at(i-1,j)) / dx
                                 : (T_old.at(i+1,j) - T_old.at(i,j)) / dx;
                // ---- Upwind y-gradient ----
                double dTy = (vy >= 0.0)
                                 ? (T_old.at(i,j) - T_old.at(i,j-1)) / dy
                                 : (T_old.at(i,j+1) - T_old.at(i,j)) / dy;

                T.at(i,j) = T_old.at(i,j) +
                            dt * (Alpha.at(i,j) * lap - vx * dTx - vy * dTy + Source.at(i,j));
            }
        }
        T.setBoundary(0.0);     // Enforce Dirichlet BCs after each step
    }

    /** Standard mean squared error between two fields. */
    static double computeMSE(const Grid2D& a, const Grid2D& b) {
        double sum = 0.0;
        for (size_t k = 0; k < a.data.size(); ++k) {
            double diff = a.data[k] - b.data[k];
            sum += diff * diff;
        }
        return sum / static_cast<double>(a.data.size());
    }
};

// =============================================================================
// Class InverseOptimizer : gradient‑based inversion
// =============================================================================
class InverseOptimizer {
public:
    HeatSolver* solver_template;   ///< Template solver for cloning
    double lr;                     ///< Learning rate
    double eps;                    ///< Finite‑difference perturbation
    double alpha_max;              ///< Upper bound for alpha (clamp)
    double rho;                    ///< RMSprop decay rate
    double eps_rms;                ///< RMSprop epsilon (avoids division by zero)
    int sim_steps;                 ///< Total forward time steps per simulation
    int record_every;              ///< Record temperature every this many steps
    std::vector<Grid2D>* target_records; ///< Multi‑time ground truth

    Grid2D grad_sq_avg;            ///< RMSprop moving average of squared gradients

    /**
     * @brief Constructor.
     * @param solver        Pointer to a HeatSolver whose dx,dy are used for cloning.
     * @param learning_rate Step size (applied after RMSprop normalization).
     * @param perturb_eps   Perturbation magnitude for finite differences.
     * @param steps         Number of forward Euler steps per simulation.
     * @param alpha_max_    Maximum allowed value of alpha.
     * @param rho_val       RMSprop decay rate (default 0.9).
     * @param eps_val       RMSprop epsilon (default 1e-6).
     * @param rec_every     Recording interval for multi‑time loss.
     * @param tgt_rec       Pointer to a vector of recorded target temperature fields.
     */
    InverseOptimizer(HeatSolver* solver, double learning_rate, double perturb_eps,
                     int steps, double alpha_max_,
                     double rho_val = 0.9, double eps_val = 1e-6,
                     int rec_every = 500, std::vector<Grid2D>* tgt_rec = nullptr)
        : solver_template(solver), lr(learning_rate), eps(perturb_eps),
          alpha_max(alpha_max_), rho(rho_val), eps_rms(eps_val),
          sim_steps(steps), record_every(rec_every), target_records(tgt_rec) {}

    /**
     * @brief Perform one training step: gradient computation, RMSprop,
     *        gradient clipping, and parameter update.
     *
     * **DeepFDM core:**
     * - Gradient is obtained by central finite differences – **no automatic
     *   differentiation**.
     * - All 800 grid points are processed in parallel with OpenMP.
     * - RMSprop normalizes the update per parameter, balancing regions with
     *   very different sensitivities.
     * - After normalization, the gradient is clipped element‑wise to [-1,1]
     *   to avoid occasional numerical spikes.
     * - Alpha is clamped to [0.001, alpha_max] after each update.
     */
    void trainStep(Grid2D& Alpha, const Grid2D& Source,
                   const Grid2D& T_init, double vx, double vy) {
        int nx = Alpha.nx, ny = Alpha.ny;

        // ---- CFL‑safe time step (0.5 × critical) ----
        double max_a = *std::max_element(Alpha.data.begin(), Alpha.data.end());
        double dt_crit = solver_template->dx * solver_template->dx / (4.0 * max_a);
        double dt_safe = 0.5 * dt_crit;
        solver_template->setDt(dt_safe);

        // ---- Lazy initialization of RMSprop state ----
        if (grad_sq_avg.nx == 0) {
            grad_sq_avg = Grid2D(nx, ny);
            std::fill(grad_sq_avg.data.begin(), grad_sq_avg.data.end(), 0.0);
        }

        Grid2D grad(nx, ny);
        std::fill(grad.data.begin(), grad.data.end(), 0.0);

        Grid2D Alpha_backup(nx, ny);
        Alpha_backup.copyFrom(Alpha);

        // ====== Parallel finite‑difference gradient computation ======
        #pragma omp parallel
        {
            HeatSolver local_solver(solver_template->dx, solver_template->dy, dt_safe);
            Grid2D T_pred(nx, ny);
            Grid2D Alpha_pert(nx, ny);
            Alpha_pert.copyFrom(Alpha_backup);

            #pragma omp for collapse(2) schedule(dynamic)
            for (int j = 0; j < ny; ++j) {
                for (int i = 0; i < nx; ++i) {
                    double orig = Alpha_backup.at(i,j);

                    // +ε
                    Alpha_pert.at(i,j) = orig + eps;
                    double Lplus = runSimulation(T_pred, Alpha_pert, Source,
                                                 vx, vy, local_solver, T_init);
                    // -ε
                    Alpha_pert.at(i,j) = orig - eps;
                    double Lminus = runSimulation(T_pred, Alpha_pert, Source,
                                                  vx, vy, local_solver, T_init);

                    Alpha_pert.at(i,j) = orig;   // restore
                    grad.at(i,j) = (Lplus - Lminus) / (2.0 * eps);
                }
            }
        }

        // ---- Diagnostic: raw gradient statistics ----
        double gmax = *std::max_element(grad.data.begin(), grad.data.end());
        double gmin = *std::min_element(grad.data.begin(), grad.data.end());
        double gavg = 0.0;
        for (double g : grad.data) gavg += std::abs(g);
        gavg /= grad.data.size();
        double g_mon = grad.at(8, 9);   // point inside the low‑α region
        {
            std::ostringstream oss;
            oss << std::scientific << std::setprecision(6);
            oss << "    [Grad] min=" << gmin << " max=" << gmax
                << " avg|grad|=" << gavg << " g(8,9)=" << g_mon;
            log_write(oss.str());
        }

        // ---- RMSprop normalization ----
        #pragma omp parallel for collapse(2)
        for (int j = 0; j < ny; ++j) {
            for (int i = 0; i < nx; ++i) {
                double g = grad.at(i,j);
                double& avg = grad_sq_avg.at(i,j);
                avg = rho * avg + (1.0 - rho) * g * g;
                grad.at(i,j) = g / (std::sqrt(avg) + eps_rms);
            }
        }

        // ---- Gradient clipping (element‑wise to [-1, 1]) ----
        #pragma omp parallel for collapse(2)
        for (int j = 0; j < ny; ++j) {
            for (int i = 0; i < nx; ++i) {
                double& g = grad.at(i,j);
                g = std::clamp(g, -1.0, 1.0);
            }
        }

        // ---- Parameter update + physical clamping ----
        #pragma omp parallel for collapse(2)
        for (int j = 0; j < ny; ++j) {
            for (int i = 0; i < nx; ++i) {
                double new_val = Alpha.at(i,j) - lr * grad.at(i,j);
                new_val = std::clamp(new_val, 0.001, alpha_max);
                Alpha.at(i,j) = new_val;
            }
        }
    }

private:
    /**
     * @brief Run a full forward simulation and return the averaged multi‑time MSE loss.
     *
     * The temperature is recorded every `record_every` steps and compared
     * against the corresponding entry in `target_records`.  The returned value
     * is the arithmetic mean over all recorded times.
     */
    double runSimulation(Grid2D& T_pred, const Grid2D& Alpha, const Grid2D& Source,
                         double vx, double vy, HeatSolver& solver,
                         const Grid2D& T_init) {
        T_pred.copyFrom(T_init);
        T_pred.setBoundary(0.0);
        double loss_sum = 0.0;
        int rec_idx = 0;
        for (int k = 1; k <= sim_steps; ++k) {
            solver.stepForward(T_pred, Alpha, Source, vx, vy);
            if (k % record_every == 0 && rec_idx < static_cast<int>(target_records->size())) {
                loss_sum += HeatSolver::computeMSE(T_pred, (*target_records)[rec_idx]);
                ++rec_idx;
            }
        }
        return (rec_idx > 0) ? loss_sum / rec_idx : 0.0;
    }
};

// -----------------------------------------------------------------------------
// Write a Grid2D to CSV file
// -----------------------------------------------------------------------------
void writeCSV(const std::string& fname, const Grid2D& g) {
    std::ofstream f(fname);
    if (!f) {
        log_write("Error opening " + fname + " for writing.");
        return;
    }
    f << std::fixed << std::setprecision(8);
    for (int j = 0; j < g.ny; ++j) {
        for (int i = 0; i < g.nx; ++i) {
            f << g.at(i,j);
            f << (i < g.nx-1 ? "," : "\n");
        }
    }
    log_write("  -> " + fname + " written");
}

// -----------------------------------------------------------------------------
// Main
// -----------------------------------------------------------------------------
int main() {
    // Open log file
    g_logfile.open("inversion.log");
    log_write("=== DeepFDM 2D thermal inversion started ===");

    const int NX = 40, NY = 20;
    const double Lx = 1.0, Ly = 0.5;
    const double dx = Lx/(NX-1), dy = Ly/(NY-1);
    const double vx = 0.0, vy = 0.0;

    // ---- True alpha field: left low (0.1), right high (0.8) ----
    Grid2D Alpha_true(NX, NY);
    for (int j = 0; j < NY; ++j)
        for (int i = 0; i < NX; ++i)
            Alpha_true.at(i,j) = (i*dx < 0.5) ? 0.1 : 0.8;

    // ---- Gaussian heat source (strong, in the low‑α region) ----
    Grid2D Source(NX, NY);
    const double src_amp = 500.0, src_sigma = 0.05, src_x0 = 0.3, src_y0 = 0.25;
    for (int j = 0; j < NY; ++j) {
        double y = j * dy;
        for (int i = 0; i < NX; ++i) {
            double x = i * dx;
            double r2 = (x - src_x0)*(x - src_x0) + (y - src_y0)*(y - src_y0);
            Source.at(i,j) = src_amp * std::exp(-r2 / (2.0 * src_sigma * src_sigma));
        }
    }

    Grid2D T_init(NX, NY);
    T_init.setBoundary(0.0);

    // ---- Generate multi‑time ground truth ----
    HeatSolver solver(dx, dy, 0.0);
    double max_a = *std::max_element(Alpha_true.data.begin(), Alpha_true.data.end());
    double dt_true = 0.5 * (dx*dx) / (4.0 * max_a);
    solver.setDt(dt_true);
    const int steps_target = 8000;
    const int record_every = 500;
    std::vector<Grid2D> target_records;
    Grid2D T = T_init;
    for (int k = 1; k <= steps_target; ++k) {
        solver.stepForward(T, Alpha_true, Source, vx, vy);
        if (k % record_every == 0)
            target_records.push_back(T);
    }
    {
        std::ostringstream oss;
        oss << "Ground truth generated, " << target_records.size()
            << " records, dt = " << dt_true
            << ", physical time = " << dt_true * steps_target << " s";
        log_write(oss.str());
    }
    writeCSV("alpha_true.csv", Alpha_true);
    writeCSV("temp_target.csv", T);   // final state for plotting

    // ---- Initial guess ----
    Grid2D Alpha_guess(NX, NY);
    std::fill(Alpha_guess.data.begin(), Alpha_guess.data.end(), 0.5);

    // ---- Optimizer (lower lr, gradient clipping, multi‑time loss) ----
    InverseOptimizer optim(&solver,
                           0.002,   // learning rate (reduced for smooth convergence)
                           0.01,    // finite‑difference epsilon
                           steps_target,
                           1.0,     // alpha_max
                           0.9,     // rho
                           1e-6,    // eps_rms
                           record_every,
                           &target_records);
    const int train_iters = 200;
    {
        std::ostringstream oss;
        oss << "\nStarting inversion (" << train_iters
            << " iterations, lr=0.002, gradient clipping, "
            << omp_get_max_threads() << " threads)";
        log_write(oss.str());
    }

    for (int iter = 1; iter <= train_iters; ++iter) {
        optim.trainStep(Alpha_guess, Source, T_init, vx, vy);

        // Report every 10 iterations
        if (iter % 10 == 0 || iter == 1) {
            double cur_max = *std::max_element(Alpha_guess.data.begin(), Alpha_guess.data.end());
            double dt_cur = 0.5 * (dx*dx) / (4.0 * cur_max);
            solver.setDt(dt_cur);
            Grid2D T_pred = T_init;
            double rep_loss = 0.0;
            int rep_idx = 0;
            for (int k = 1; k <= steps_target; ++k) {
                solver.stepForward(T_pred, Alpha_guess, Source, vx, vy);
                if (k % record_every == 0 && rep_idx < (int)target_records.size())
                    rep_loss += HeatSolver::computeMSE(T_pred, target_records[rep_idx++]);
            }
            rep_loss /= rep_idx;
            double amin = *std::min_element(Alpha_guess.data.begin(), Alpha_guess.data.end());
            double amax = *std::max_element(Alpha_guess.data.begin(), Alpha_guess.data.end());
            double left_alpha = Alpha_guess.at(8, 9);

            std::ostringstream oss;
            oss << "Iter " << std::setw(4) << iter
                << "  Loss: " << std::scientific << std::setprecision(6) << rep_loss
                << "  α ∈ [" << std::fixed << std::setprecision(6) << amin
                << ", " << amax << "]"
                << "  Left(8,9)=" << left_alpha;
            log_write(oss.str());
        }
    }

    writeCSV("alpha_inferred.csv", Alpha_guess);
    log_write("\nInversion finished. Compare alpha_true.csv and alpha_inferred.csv.");
    log_write("If left half shows low conductivity (≈0.1) and right half high (≈0.8), the DeepFDM logic succeeded.");

    g_logfile.close();
    return 0;
}