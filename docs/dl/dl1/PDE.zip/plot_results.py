#!/usr/bin/env python3
"""
plot_results.py
Plot true alpha, inferred alpha, and target temperature fields from CSV files.
Usage: activate your venv, install requirements, then run:
    python plot_results.py
"""

import numpy as np
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# 1. Load data (ensure CSV files are in the current directory)
# ------------------------------------------------------------
alpha_true  = np.loadtxt('alpha_true.csv', delimiter=',')
alpha_infer = np.loadtxt('alpha_inferred.csv', delimiter=',')
temp_target = np.loadtxt('temp_target.csv', delimiter=',')

# Determine grid dimensions (should be 20 rows x 40 cols)
ny, nx = alpha_true.shape

# ------------------------------------------------------------
# 2. Create a 1x3 subplot figure
# ------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Common extent: x = [0, 1.0] m, y = [0, 0.5] m
extent = [0, 1.0, 0, 0.5]

# ---- (a) True alpha field ----
im1 = axes[0].imshow(alpha_true, cmap='hot', origin='lower',
                     vmin=0.0, vmax=1.0, extent=extent, aspect='auto')
axes[0].set_title(r'True $\alpha(x,y)$')
axes[0].set_xlabel('x [m]')
axes[0].set_ylabel('y [m]')
fig.colorbar(im1, ax=axes[0], label=r'$\alpha$')

# ---- (b) Inferred alpha field ----
im2 = axes[1].imshow(alpha_infer, cmap='hot', origin='lower',
                     vmin=0.0, vmax=1.0, extent=extent, aspect='auto')
axes[1].set_title(r'Inferred $\alpha(x,y)$')
axes[1].set_xlabel('x [m]')
axes[1].set_ylabel('y [m]')
fig.colorbar(im2, ax=axes[1], label=r'$\alpha$')

# ---- (c) Target temperature field (final state) ----
im3 = axes[2].imshow(temp_target, cmap='coolwarm', origin='lower',
                     extent=extent, aspect='auto')
axes[2].set_title(r'Target $T(x,y)$ (final)')
axes[2].set_xlabel('x [m]')
axes[2].set_ylabel('y [m]')
fig.colorbar(im3, ax=axes[2], label='Temperature')

# ------------------------------------------------------------
# 3. Adjust layout and save/show
# ------------------------------------------------------------
plt.tight_layout()
plt.savefig('comparison.png', dpi=150, bbox_inches='tight')
plt.show()